<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit();
}
// Obtiene parámetros de la URL
$parking   = isset($_GET['parking']) ? htmlspecialchars($_GET['parking']) : '—';
$horas     = isset($_GET['horas'])   ? (int)$_GET['horas']         : 0;
$precioHora = 20; // tarifa por hora
$total     = $horas * $precioHora;
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Pagar Estacionamiento</title>

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet" />
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

  <style>
    :root {
      --primary: #1e88e5;
      --primary-hover: #1565c0;
      --bg: #f7f9fc;
      --card: #ffffff;
      --accent: #ffca28;
      --text: #333;
      --shadow: rgba(0, 0, 0, 0.1);
    }
    * { margin:0; padding:0; box-sizing:border-box; font-family:'Poppins',sans-serif; }
    body {
      background: var(--bg);
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      padding:1rem;
    }
    .card-container {
      background: var(--card);
      border-radius: 1.5rem;
      box-shadow: 0 8px 20px var(--shadow);
      overflow: hidden;
      max-width: 420px;
      width: 100%;
    }
    .card-header {
      background: var(--primary);
      padding: 1.5rem;
      text-align: center;
    }
    .card-header h3 {
      color: #fff;
      font-weight: 600;
      font-size: 1.5rem;
    }
    .card-body {
      padding: 2rem;
    }
    .card-body .info-item {
      margin-bottom: 1rem;
      font-size: 1rem;
      color: var(--text);
    }
    .card-body .info-item span {
      font-weight: 600;
      color: var(--primary-hover);
    }
    .form-group {
      position: relative;
      margin-bottom: 1.5rem;
    }
    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 500;
    }
    .form-group .icon {
      position: absolute;
      top: 50%;
      left: 1rem;
      transform: translateY(-50%);
      color: var(--primary);
      pointer-events: none;
    }
    .form-group input {
      width: 100%;
      padding: 0.75rem 1rem;
      padding-left: 2.5rem;
      border: 1px solid #ddd;
      border-radius: 0.75rem;
      transition: border 0.3s;
      font-size: 1rem;
    }
    .form-group input:focus {
      border-color: var(--primary-hover);
      outline: none;
    }
    .btn-pay {
      display: block;
      width: 100%;
      padding: 0.75rem;
      font-size: 1rem;
      font-weight: 600;
      color: #fff;
      background: var(--accent);
      border: none;
      border-radius: 0.75rem;
      cursor: pointer;
      transition: background 0.3s, transform 0.2s;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .btn-pay:hover {
      background: darken(var(--accent), 10%);
      transform: translateY(-2px);
    }
    .btn-pay:active {
      transform: translateY(0);
    }
  </style>
</head>
<body>
  <div class="card-container">
    <div class="card-header">
      <h3>Pagar Estacionamiento</h3>
    </div>
    <div class="card-body">
      <!-- Detalles de la reserva -->
      <div class="info-item">Estacionamiento: <span><?php echo $parking; ?></span></div>
      <div class="info-item">Horas: <span><?php echo $horas; ?></span></div>
      <div class="info-item">Precio x hora: <span>$<?php echo number_format($precioHora, 2); ?></span></div>
      <div class="info-item">Total a pagar: <span>$<?php echo number_format($total, 2); ?></span></div>

      <!-- Formulario de pago -->
      <form action="confirmacion.php" method="POST">
        <input type="hidden" name="parking" value="<?php echo $parking; ?>" />
        <input type="hidden" name="horas"   value="<?php echo $horas; ?>" />
        <input type="hidden" name="total"   value="<?php echo $total; ?>" />

        <div class="form-group">
          <label for="titular">Nombre del titular</label>
          <i class="fa fa-user icon"></i>
          <input type="text" id="titular" name="titular" placeholder="Juan Pérez" required />
        </div>
        <div class="form-group">
          <label for="tarjeta">Número de tarjeta</label>
          <i class="fa fa-credit-card icon"></i>
          <input type="text" id="tarjeta" name="tarjeta" placeholder="1234 5678 9012 3456" maxlength="19" required />
        </div>
        <div class="form-group">
          <label for="expiracion">Fecha de expiración</label>
          <i class="fa fa-calendar icon"></i>
          <input type="month" id="expiracion" name="expiracion" required />
        </div>
        <div class="form-group">
          <label for="cvv">CVV</label>
          <i class="fa fa-lock icon"></i>
          <input type="text" id="cvv" name="cvv" placeholder="123" maxlength="3" required />
        </div>

        <button type="submit" class="btn-pay">Pagar y Confirmar</button>
      </form>
    </div>
  </div>
</body>
</html>
