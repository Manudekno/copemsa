<?php
// 1. Mostrar errores para depuración (desactívalo en producción)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// 2. Iniciar buffer de salida y limpiar posibles salidas previas
if (ob_get_length()) ob_end_clean();
ob_start();

// 3. Cargar PhpSpreadsheet
require __DIR__ . '/vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// 4. Conexión a base de datos
$mysqli = new mysqli("localhost", "root", "", "copemsa");
if ($mysqli->connect_errno) {
    http_response_code(500);
    exit("Error al conectar: " . $mysqli->connect_error);
}

// 5. Consulta SQL
$query = "
  SELECT
    r.id,
    u.nombre    AS cliente,
    u.correo    AS correo,
    e.nombre    AS estacionamiento,
    r.fecha     AS inicio,
    DATE_ADD(r.fecha, INTERVAL r.horas HOUR) AS fin,
    r.horas,
    r.total
  FROM reservas r
  JOIN usuarios u ON r.usuario_id = u.id
  JOIN estacionamientos e ON r.estacionamiento_id = e.id
  ORDER BY r.fecha
";
$resultado = $mysqli->query($query);
if (!$resultado) {
    http_response_code(500);
    exit("Error en la consulta SQL: " . $mysqli->error);
}

// 6. Crear hoja de cálculo
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Encabezados
$sheet->fromArray(['ID','Cliente','Correo','Estacionamiento','Inicio','Fin','Horas','Total'], null, 'A1');

// Rellenar datos
$fila = 2;
while ($row = $resultado->fetch_assoc()) {
    $sheet->fromArray([
        $row['id'],
        $row['cliente'],
        $row['correo'],
        $row['estacionamiento'],
        $row['inicio'],
        $row['fin'],
        $row['horas'],
        $row['total']
    ], null, "A{$fila}");
    $fila++;
}

// 7. Limpiar buffers antes de enviar
while (ob_get_level()) ob_end_clean();

// 8. Cabeceras de descarga
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="reservas.xlsx"');
header('Cache-Control: max-age=0');
header('Expires: 0');
header('Pragma: public');

// 9. Guardar en la salida
$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
