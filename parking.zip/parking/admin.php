<?php
session_start();

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Conexión a la base de datos
$conexion = new mysqli("localhost", "root", "", "copemsa");
$conexion->set_charset("utf8");

// Consultas corregidas usando los nombres de columnas reales
// Reservas activas
$sqlActivas = "
  SELECT r.id,
         u.nombre    AS cliente,
         u.correo    AS correo,
         e.nombre    AS estacionamiento,
         r.fecha,
         r.horas,
         r.total,
         DATE_ADD(r.fecha, INTERVAL r.horas HOUR) AS fin_reserva
  FROM reservas r
  JOIN usuarios u ON r.usuario_id = u.id
  JOIN estacionamientos e ON r.estacionamiento_id = e.id
  WHERE DATE_ADD(r.fecha, INTERVAL r.horas HOUR) >= NOW()
  ORDER BY r.fecha, r.horas
";
$activas = $conexion->query($sqlActivas);

// Reservas vencidas
$sqlVencidas = "
  SELECT r.id,
         u.nombre    AS cliente,
         u.correo    AS correo,
         e.nombre    AS estacionamiento,
         r.fecha,
         r.horas,
         r.total,
         DATE_ADD(r.fecha, INTERVAL r.horas HOUR) AS fin_reserva
  FROM reservas r
  JOIN usuarios u ON r.usuario_id = u.id
  JOIN estacionamientos e ON r.estacionamiento_id = e.id
  WHERE DATE_ADD(r.fecha, INTERVAL r.horas HOUR) < NOW()
  ORDER BY r.fecha DESC, r.horas DESC
";
$vencidas = $conexion->query($sqlVencidas);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Administración de Reservas</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { padding: 30px; background: #f8f9fa; }
    .table thead { background-color: #007bff; color: white; }
    .btn-delete { background-color: #dc3545; color: white; }
    .btn-delete:hover { background-color: #c82333; }
    h2 { margin-top: 40px; }
  </style>
</head>
<body>
  <div class="container">
    <h1 class="mb-4">Panel de Administración</h1>
    <div class="d-flex justify-content-end mb-3">
      <a href="exportar_excel.php" class="btn btn-success">📥 Exportar a Excel</a>
    </div>

    <!-- Reservaciones Activas -->
    <h2>Reservaciones Activas</h2>
    <table class="table table-bordered table-hover">
      <thead>
        <tr>
          <th>ID</th><th>Cliente</th><th>Correo</th><th>Estacionamiento</th>
          <th>Inicio</th><th>Fin</th><th>Horas</th><th>Total</th><th>Acciones</th>
        </tr>
      </thead>
      <tbody>
      <?php if ($activas && $activas->num_rows): ?>
        <?php while($r = $activas->fetch_assoc()): ?>
        <tr>
          <td><?= $r['id'] ?></td>
          <td><?= htmlspecialchars($r['cliente']) ?></td>
          <td><?= htmlspecialchars($r['correo']) ?></td>
          <td><?= htmlspecialchars($r['estacionamiento']) ?></td>
          <td><?= $r['fecha'] ?></td>
          <td><?= $r['fin_reserva'] ?></td>
          <td><?= $r['horas'] ?></td>
          <td>$<?= number_format($r['total'], 2) ?></td>
          <td>
            <a href="eliminar.php?id=<?= $r['id'] ?>" 
               class="btn btn-sm btn-delete" 
               onclick="return confirm('¿Eliminar esta reserva?')">
              Eliminar
            </a>
          </td>
        </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="9" class="text-center">No hay reservas activas.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>

    <!-- Reservaciones Vencidas -->
    <h2>Reservaciones Vencidas</h2>
    <table class="table table-bordered table-hover">
      <thead>
        <tr>
          <th>ID</th><th>Cliente</th><th>Correo</th><th>Estacionamiento</th>
          <th>Inicio</th><th>Fin</th><th>Horas</th><th>Total</th><th>Acciones</th>
        </tr>
      </thead>
      <tbody>
      <?php if ($vencidas && $vencidas->num_rows): ?>
        <?php while($r = $vencidas->fetch_assoc()): ?>
        <tr>
          <td><?= $r['id'] ?></td>
          <td><?= htmlspecialchars($r['cliente']) ?></td>
          <td><?= htmlspecialchars($r['correo']) ?></td>
          <td><?= htmlspecialchars($r['estacionamiento']) ?></td>
          <td><?= $r['fecha'] ?></td>
          <td><?= $r['fin_reserva'] ?></td>
          <td><?= $r['horas'] ?></td>
          <td>$<?= number_format($r['total'], 2) ?></td>
          <td>
            <a href="eliminar.php?id=<?= $r['id'] ?>" 
               class="btn btn-sm btn-delete" 
               onclick="return confirm('¿Eliminar esta reserva vencida?')">
              Eliminar
            </a>
          </td>
        </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="9" class="text-center">No hay reservas vencidas.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>

  </div>
</body>
</html>
