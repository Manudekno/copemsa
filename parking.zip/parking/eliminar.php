<?php
session_start();
// 1) Validar sesión y rol
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// 2) Conectar a la base de datos
$conexion = new mysqli("localhost", "root", "", "copemsa");
$conexion->set_charset("utf8");

// 3) Obtener y sanitizar el ID a borrar
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id > 0) {
    // 4) Ejecutar el DELETE
    $conexion->query("DELETE FROM reservas WHERE id = $id");
}

// 5) Redirigir de vuelta al admin
header("Location: admin.php");
exit;