<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit();
}

require 'db_config.php';  // Aquí defines $conn como mysqli

// 1) Recoger datos del formulario
$parking = trim($_POST['parking'] ?? '');
$horas   = (int) ($_POST['horas'] ?? 0);
$total   = (float) ($_POST['total'] ?? 0.00);
$titular = trim($_POST['titular'] ?? 'Cliente');

// 2) Obtener ID del usuario
$stmt = $conn->prepare("SELECT id FROM usuarios WHERE correo = ?");
$stmt->bind_param('s', $_SESSION['usuario']);
$stmt->execute();
$stmt->bind_result($usuario_id);
$stmt->fetch();
$stmt->close();

// 3) Obtener o crear registro en estacionamientos
$stmt = $conn->prepare("SELECT id FROM estacionamientos WHERE nombre = ?");
$stmt->bind_param('s', $parking);
$stmt->execute();
$stmt->bind_result($estacionamiento_id);
if (!$stmt->fetch()) {
    // No existe, lo creamos
    $stmt->close();
    $stmt = $conn->prepare("INSERT INTO estacionamientos (nombre) VALUES (?)");
    $stmt->bind_param('s', $parking);
    $stmt->execute();
    $estacionamiento_id = $stmt->insert_id;
}
$stmt->close();

// 4) Insertar la reserva
$stmt = $conn->prepare(
    "INSERT INTO reservas 
       (usuario_id, estacionamiento_id, fecha, horas, total)
     VALUES 
       (?, ?, NOW(), ?, ?)"
);
$stmt->bind_param('iiid', $usuario_id, $estacionamiento_id, $horas, $total);
$stmt->execute();
$reservaId = $stmt->insert_id;
$stmt->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Confirmación de Reserva</title>

  <!-- Google Fonts -->
  <link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap"
    rel="stylesheet"
  />
  <!-- Font Awesome -->
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
  />

  <style>
    :root {
      --primary: #1e88e5;
      --primary-hover: #1565c0;
      --bg: #f7f9fc;
      --card: #ffffff;
      --accent: #4caf50;
      --text: #333;
      --shadow: rgba(0, 0, 0, 0.1);
    }
    * {
      margin: 0; padding: 0; box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }
    body {
      background: var(--bg);
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      padding: 1rem;
    }
    .card-container {
      background: var(--card);
      border-radius: 1.5rem;
      box-shadow: 0 8px 20px var(--shadow);
      overflow: hidden;
      max-width: 420px;
      width: 100%;
    }
    .card-header {
      background: var(--primary);
      padding: 1.5rem;
      text-align: center;
    }
    .card-header h3 {
      color: #fff;
      font-weight: 600;
      font-size: 1.5rem;
      margin-top: .5rem;
    }
    .card-body {
      padding: 2rem;
    }
    .card-body .info-item {
      margin-bottom: 1rem;
      font-size: 1rem;
      color: var(--text);
    }
    .card-body .info-item span {
      font-weight: 600;
      color: var(--accent);
    }
    .btn-home {
      display: block;
      text-align: center;
      padding: .75rem 1rem;
      margin-top: 1.5rem;
      background: var(--accent);
      color: #fff;
      text-decoration: none;
      border-radius: .75rem;
      font-weight: 600;
      transition: background .3s, transform .2s;
    }
    .btn-home:hover {
      background: var(--primary-hover);
      transform: translateY(-2px);
    }
    .btn-home:active {
      transform: translateY(0);
    }
  </style>
</head>
<body>
  <div class="card-container">
    <div class="card-header">
      <i class="fa fa-check-circle fa-3x" style="color: var(--accent);"></i>
      <h3>¡Reserva Confirmada!</h3>
    </div>
    <div class="card-body">
      <div class="info-item">Num. de Reserva: <span><?= htmlspecialchars($reservaId) ?></span></div>
      <div class="info-item">Titular: <span><?= htmlspecialchars($titular) ?></span></div>
      <div class="info-item">Estacionamiento: <span><?= htmlspecialchars($parking) ?></span></div>
      <div class="info-item">Horas: <span><?= $horas ?></span></div>
      <div class="info-item">Total Pagado: <span>$<?= number_format($total, 2) ?></span></div>
      <a href="index.html" class="btn-home">Volver al Inicio</a>
    </div>
  </div>
</body>
</html>
